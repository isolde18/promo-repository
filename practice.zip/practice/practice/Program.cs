﻿using System;

namespace practice
{
    class Program
    {
        
        static void Main(string[] args)
        {
           BookAuthor();
           Saying();
        }
        static void BookAuthor()
        {
            string name = "Anais Nin";
            int age = 73;
            string quote = "We write to taste life twice";
            var date = DateTime.Now;
            Console.WriteLine($"{name} was an author. She chose to have no children. She died when she was {age} year{(age == 1 ? "":"s")} old from cervical cancer.");
            Console.WriteLine("Anais Nin wrote: {0}!\nToday is {1}, it's {2:HH:mm} now.", quote, date.DayOfWeek, date);//composite formatting
            Console.WriteLine($"Anais Nin: {quote}!\nToday is {date.DayOfWeek}, it's {date:HH:mm} now.\nThis quote" +
                $" has {quote.Length} letters.");
            }
        static void Saying()
        {
            string quote2 = "in the moment and in retrospection";
            Console.WriteLine($"The prase: {quote2} has totally {quote2.Length} letters or elements.");
            Console.WriteLine(quote2.ToUpper());
            Console.WriteLine(quote2.ToLower());
            Console.WriteLine($"The 26th element is: {quote2[26]}");//counts every element starting from 0
            Console.WriteLine($"Does contain the word write: { quote2.Contains("write")}");// returns true (or false)
            Console.WriteLine($"Does contain the word retrospection: { quote2.Contains("retrospection")}");// returns true (or false)
            Console.WriteLine(quote2.IndexOf("and"));//21
            Console.WriteLine(quote2.IndexOf("o"));//8
            Console.WriteLine(quote2[3]);//t
            Console.WriteLine(quote2.Substring(0,18));//the substring in from 0 to 18 'in the moment and' 
        }
    }
}

