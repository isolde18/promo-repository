﻿CREATE PROCEDURE [dbo].[spPersonFilterbyLastName]
	@LastName nvarchar(50)
AS
begin
	SELECT [PersonId], [FirstName], [LastName]
	FROM dbo.Person
	WHERE LastName =@LastName
end
	
