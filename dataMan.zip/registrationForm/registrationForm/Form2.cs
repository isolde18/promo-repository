﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace registrationForm
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string connetionString;
            SqlConnection cnn;

            connetionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\FTCC\source\repos\registrationForm\registrationForm\Data.mdf;Integrated Security=True;Connect Timeout=30";

            cnn = new SqlConnection(connetionString);
            cnn.Open();

            //Define variables for select to read with SQL DATA READER

            //SqlCommand command;
            //SqlDataReader dataReader;
            //String sql, Output = "";

            //Define sql statement

            //sql = "SELECT TOP 1000 [Id] ,[username] ,[password] FROM [dbo].[Table]";

            //Define variables for insert with SQL DATA ADAPTER SAME As
            //Define the sql command

            SqlCommand command;
            SqlDataAdapter adapter = new SqlDataAdapter();
            string sql = "";

            //Define the insert statement with insert 

            //sql = "insert into [dbo].[Table] ([Id], [username], [password],) VALUES (3,' " + "user3" +" zxcvbn "+ " ')";

            //sql = "Insert INTO [dbo].[Table] (Id,username,password) values (' ," + "user3" + " zxcvbn')";

            //sql = "INSERT INTO[dbo].[Table]([Id], [username], [password]) VALUES(3, N'user3     ', N'zxcvbn    ')";
            
            //Define the update statement with update

             sql = "Update [dbo].[Table] set username = ' "+" user3complete" +" 'where Id = 1";//it was where Id=3 before deleting row

            //Define the delete rows with delete

            //sql = "Delete [dbo].[Table] where Id = 3";//only one sql statement at a time


            command = new SqlCommand(sql, cnn);

            //Associate the insert command
            //Define the adapter insert command

            //adapter.InsertCommand = new SqlCommand(sql, cnn);
            //adapter.InsertCommand.ExecuteNonQuery();

            adapter.UpdateCommand = new SqlCommand(sql, cnn);
            adapter.UpdateCommand.ExecuteNonQuery();

            //adapter.DeleteCommand = new SqlCommand(sql, cnn);
            //adapter.DeleteCommand.ExecuteNonQuery();

            //Define the date reader
            //Associate the dataReader command

            //dataReader = command.ExecuteReader();

            //Display the output to the user

            //while (dataReader.Read())
            //{
            //    Output = Output + dataReader.GetValue(0) + " - "
            //     + dataReader.GetValue(1) + "\n";
            //}

            //MessageBox.Show("Connection Open !");

            //Close all objects

            //MessageBox.Show(Output);
            //dataReader.Close();
            command.Dispose();
            cnn.Close();
        }
    }
}
